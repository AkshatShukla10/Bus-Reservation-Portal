package com.validation;
import java.sql.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

public class ValidateCustomerBasicDetails {
	
	@NotNull(message = "Emailid is Empty")
	@Email(message = "Email id not in format")
	private String emailid;
	@NotNull(message = "DOB is empty")
	@DateTimeFormat(pattern = "yyyy-dd-mm")
	private Date birthdate;
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

}
