package com.validation;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class ValidateUpdateDetail {

	public ValidateUpdateDetail(
			@NotNull(message = "pincode can't be NULL") @Pattern(regexp = "^[1-9]{1}[0-9]{2}\\\\s{0, 1}[0-9]{3}$") long pincode,
			@NotNull(message = "address can't be NULL") @Pattern(regexp = "^[a-zA-Z ]{1,25}$", message = "Address length 25 digit excceded") String address,
			@NotNull(message = "city cant be NULL") @Pattern(regexp = "^[a-zA-Z ]{1,25}$", message = "City/State should not contain any special characters except space") String city,
			@NotNull(message = "state can't be NULL") @Pattern(regexp = "^[a-zA-Z ]{1,25}$", message = "City/State should not contain any special characters except space") String state) {
		this.pincode = pincode;
		this.address = address;
		this.city = city;
		this.state = state;
	}
	@NotNull(message = "pincode can't be NULL")
	@Pattern(regexp="^[1-9]{1}[0-9]{2}\\\\s{0, 1}[0-9]{3}$")
	private long pincode;
	@NotNull(message = "address can't be NULL")
	@Pattern(regexp = "^[a-zA-Z ]{1,25}$",message = "Address length 25 digit excceded")
	private String address;
	@NotNull(message = "city cant be NULL")
	@Pattern(regexp = "^[a-zA-Z ]{1,25}$",message = "City/State should not contain any special characters except space")
	private String city;
	@NotNull(message = "state can't be NULL")
	@Pattern(regexp = "^[a-zA-Z ]{1,25}$",message = "City/State should not contain any special characters except space")
	private String state;
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
