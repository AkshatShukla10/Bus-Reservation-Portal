package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entity.CustomerAddress;

@Repository
public interface AddCustomerAddressRepo extends JpaRepository<CustomerAddress, Integer> {

	@Query(value = "INSERT into Customer_Address(pincode,address,city,state) values (?1,?2,?3,?4)", nativeQuery = true)
	public void InsertCustomerAddress(String pincode,String add,String city,String state);
}
