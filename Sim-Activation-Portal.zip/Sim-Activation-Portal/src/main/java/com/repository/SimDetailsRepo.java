package com.repository;

import com.entity.SimDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SimDetailsRepo extends JpaRepository<SimDetails,Integer>{
	
	@Query("select s from SimDetails s where s.simNumber=?1 and s.serviceNumber=?2")
	public SimDetails findBySimNumerAndServiceNumber(String simnumber,String servicenumber);
	
	@Query(value = "update SimDetails set simStatus=?1 where simId=?2")
	public void updateSimStatus(String status,int simid);
}
