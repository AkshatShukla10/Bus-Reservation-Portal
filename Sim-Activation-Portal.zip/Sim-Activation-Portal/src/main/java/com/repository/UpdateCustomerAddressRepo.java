package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entity.CustomerAddress;

@Repository
public interface UpdateCustomerAddressRepo extends JpaRepository<CustomerAddress, Integer> {

	@Query(value = "update CustomerAddress set pincode= ?1 ,address=?2 where city=?3 and state=?4")
	public void updateCustomerAddress(String pincode,String add,String city,String state);

}
