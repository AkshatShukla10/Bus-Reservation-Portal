package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entity.SimDetails;

@Repository
public interface GetSimStatusRepo  extends JpaRepository<SimDetails, Integer>{

	public SimDetails findBySimId(int simid);
}
