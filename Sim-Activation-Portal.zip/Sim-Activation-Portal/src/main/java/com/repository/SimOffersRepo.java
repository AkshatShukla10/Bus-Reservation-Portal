package com.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.entity.SimOffers;

@Repository
public interface SimOffersRepo extends JpaRepository<SimOffers, Integer> {

	public SimOffers findBySimid(int simid);
}
