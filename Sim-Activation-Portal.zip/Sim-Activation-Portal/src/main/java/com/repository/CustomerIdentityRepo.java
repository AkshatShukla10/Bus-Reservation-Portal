package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entity.CustomerIdentity;

@Repository
public interface CustomerIdentityRepo extends JpaRepository<CustomerIdentity, String> {

	public CustomerIdentity findByFirstNameAndLastName(String firstname,String lastname);
}
