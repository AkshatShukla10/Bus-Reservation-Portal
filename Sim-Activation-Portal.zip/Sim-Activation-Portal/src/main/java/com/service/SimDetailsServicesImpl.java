package com.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.DTO.SimDetailsDTO;
import com.entity.SimDetails;
import com.entity.SimOffers;
import com.repository.GetSimStatusRepo;
import com.repository.SimDetailsRepo;
import com.repository.SimOffersRepo;

public class SimDetailsServicesImpl implements SimDetailsServices {
	
	@Autowired
	public SimDetailsRepo simDetailsRepository;
	@Autowired
	public SimOffersRepo simOffersRepository;
	@Autowired
	public GetSimStatusRepo getSimStatisRepository;

	@Override
	public SimDetails verificationservice(String simnumber, String servicenumber) {
		return simDetailsRepository.findBySimNumerAndServiceNumber(simnumber, servicenumber);
	}

	@Override
	public SimOffers getSimOfferDetails(int simid) {
		return simOffersRepository.findBySimid(simid);
	}

	@Override
	public SimDetailsDTO getsimPlans(int simid) {
		return SimDetailsDTO.valueOf(getSimStatisRepository.findBySimId(simid));
	}

}
