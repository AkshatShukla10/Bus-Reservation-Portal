package com.service;

import java.sql.Date;

import org.springframework.stereotype.Service;

import com.DTO.SimDetailsDTO;
import com.entity.Customer;

@Service
public interface CustomerServices {
	
	public Customer verifycustomerbasicdetail(Date dob,String emailid);
	public Customer VerifyIdProof(String idNumber);
	public SimDetailsDTO verifysimstatus(int simid);
	public void updatesimstatus(String status,int simid) ;

}
