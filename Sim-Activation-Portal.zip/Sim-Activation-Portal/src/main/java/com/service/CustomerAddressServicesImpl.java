package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.repository.AddCustomerAddressRepo;
import com.repository.CustomerAddressRepo;
import com.repository.UpdateCustomerAddressRepo;

@Service
public class CustomerAddressServicesImpl implements CustomerAddressServices {

	@Autowired
	private CustomerAddressRepo customerAddressRepository;
	
	@Autowired
	private AddCustomerAddressRepo addCustomerAddressRepository;
	
	@Autowired
	private UpdateCustomerAddressRepo updateCustomerAddressRepository;
	@Override
	public String updationCustomerAddress(String pincode, String add, String city, String State) {
		if(customerAddressRepository.findByCityAndState(city, State)==null)
		{
			addCustomerAddressRepository.InsertCustomerAddress(pincode, add, city, State);
			return "New Address added Sucessfully";
		}
		else {
			updateCustomerAddressRepository.updateCustomerAddress(pincode, add, city, State);
			return "Address Updated Sucessfully";
		}
		
	}
}
