package com.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.DTO.SimDetailsDTO;
import com.entity.Customer;
import com.repository.CustomerRepo;
import com.repository.SimDetailsRepo;

public class CustomerServicesImpl implements CustomerServices {

	@Autowired
	private CustomerRepo customerRepository;
	
	@Autowired
	private SimDetailsRepo simDetailsRepository;
	
	@Override
	public Customer verifycustomerbasicdetail(Date dob, String emailid) {
		return customerRepository.findByDateOfBirthAndEmailAddress(dob, emailid);
	}
	@Override
	public Customer VerifyIdProof(String idNumber) {
		return customerRepository.findByUniqueIdNumber(idNumber);
	}
	@Override
	public SimDetailsDTO verifysimstatus(int simid) {
		return null;

		
		
	}
	@Override
	public void updatesimstatus(String status, int simid) {
		simDetailsRepository.updateSimStatus(status, simid);		
	}
}
