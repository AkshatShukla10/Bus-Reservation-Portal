package com.service;

import org.springframework.stereotype.Service;

import com.entity.CustomerIdentity;

@Service
public interface CustomerIdentityServices {

	public CustomerIdentity verificationCustomerIdentity (String firstname,String lastname) ;
}
